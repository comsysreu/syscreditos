		</div> <!-- Fin del contenedor -->
		<footer  >
			<p style="padding-left: 2%;">&copy; TyDweb Inc. <?php echo date('Y'); ?></p>
		</footer>
	    <script src="../js/bootstrap-transition.js"></script>
	    <script src="../js/bootstrap-alert.js"></script>
	    <script src="../js/bootstrap-modal.js"></script>
	    <script src="../js/bootstrap-dropdown.js"></script>
	    <script src="../js/bootstrap-scrollspy.js"></script>
	    <script src="../js/bootstrap-tab.js"></script>
	    <script src="../js/bootstrap-tooltip.js"></script>
	    <script src="../js/bootstrap-popover.js"></script>
	    <script src="../js/bootstrap-button.js"></script>
	    <script src="../js/bootstrap-collapse.js"></script>
	    <script src="../js/bootstrap-carousel.js"></script>
	    <script src="../js/bootstrap-typeahead.js"></script>
	    <script src="../js/prefixfree.min.js"></script>
    	<script src="../js/jquery.validate.js"></script>
    	<script src="../js/jquery-ui.min.js"></script>
    	<script type="text/javascript" charset="utf-8" language="javascript" src="../js/jquery.dataTables.js"></script>
    	<script type="text/javascript" charset="utf-8" language="javascript" src="../js/DT_bootstrap.js"></script>
    	<script type="text/javascript" src="../js/jquery.scrollto.js"></script>
    	<script type="text/javascript" src="../js/highcharts.js"></script> 
		<script type="text/javascript" src="../js/modules/exporting.js"></script>
	</body>
</html>