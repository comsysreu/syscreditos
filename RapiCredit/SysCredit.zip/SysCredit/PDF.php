<?php
require('fpdf/fpdf.php');
class PDF extends FPDF
{
}
?>